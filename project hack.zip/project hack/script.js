function sendMessage() {
    var user_input = document.getElementById("user-input").value.trim();
    if (user_input === "") {
        return;
    }
    document.getElementById("user-input").value = "";

    var chat_box = document.getElementById("chat-box");
    
    // Add user message to the chat box
    var user_message = document.createElement("div");
    user_message.classList.add("user-message");
    user_message.innerHTML = "<p>" + user_input + "</p>";
    chat_box.appendChild(user_message);
    chat_box.scrollTop = chat_box.scrollHeight;

    // Send user input to backend for processing
    fetch("/get_response", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: user_input }),
    })
    .then(response => response.json())
    .then(data => {
        // Add bot reply to the chat box
        var bot_message = document.createElement("div");
        bot_message.classList.add("bot-message");
        bot_message.innerHTML = "<p>" + data.response + "</p>";
        chat_box.appendChild(bot_message);
        chat_box.scrollTop = chat_box.scrollHeight;
    });
}

function showGeneralInfo() {
    var chat_box = document.getElementById("chat-box");
    
    // Add general health information to the chat box
    var info_message = document.createElement("div");
    info_message.classList.add("bot-message");
    info_message.innerHTML = "<p>Here is some general health information...</p>";
    chat_box.appendChild(info_message);
    chat_box.scrollTop = chat_box.scrollHeight;
}

function showAppointmentForm() {
    document.getElementById("appointment-modal").style.display = "block";
}

function closeModal() {
    document.getElementById("appointment-modal").style.display = "none";
}
